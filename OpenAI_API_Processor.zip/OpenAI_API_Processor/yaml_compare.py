import yaml

def compare_yaml_files_with_threshold(base_file, compare_file, key_phrase, threshold=9):
    """
    Compare two YAML files based on a key phrase appearing anywhere in the string,
    allowing for a timestamp offset threshold.

    Args:
        base_file (str): Path to the base (ground truth) YAML file.
        compare_file (str): Path to the comparison YAML file.
        key_phrase (str): Key phrase to filter and compare lines.
        threshold (int): Allowed timestamp difference for matching (in seconds).

    Prints:
        Accuracy percentage and detailed counts of matching lines.
    """
    # Load both YAML files
    with open(base_file, 'r') as f:
        base_data = yaml.safe_load(f)

    with open(compare_file, 'r') as f:
        compare_data = yaml.safe_load(f)

    # Initialize counters
    total_matches = 0
    correct_matches = 0

    # Iterate through timestamps in the base file
    for base_timestamp, base_entry in base_data.items():
        # Check if the key phrase appears in the base entry
        if base_entry and key_phrase.lower() in base_entry.lower():
            total_matches += 1  # Count this as a valid match candidate

            # Check for a matching timestamp in the comparison file within the threshold
            found_match = False
            for offset in range(-threshold, threshold + 1):
                compare_timestamp = base_timestamp + offset
                if compare_timestamp in compare_data:
                    compare_entry = compare_data[compare_timestamp]
                    if compare_entry and key_phrase.lower() in compare_entry.lower():
                        found_match = True
                        break

            if found_match:
                correct_matches += 1

    # Calculate percentage accuracy
    accuracy = (correct_matches / total_matches) * 100 if total_matches > 0 else 0

    # Print the results
    print(f"Total matching lines in base file with key phrase '{key_phrase}': {total_matches}")
    print(f"Correct matching lines in comparison file (within ±{threshold} seconds): {correct_matches}")
    print(f"Accuracy: {accuracy:.2f}%")

# Example usage:
compare_yaml_files_with_threshold("ground_truth.yaml", "output2.yaml", "CoNtext")