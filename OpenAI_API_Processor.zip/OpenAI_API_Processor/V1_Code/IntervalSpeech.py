import csv


def extract_text_from_csv(file_path, start_interval, end_interval):
    """Extract text from CSV based on time interval and format with ones place index."""
    interval_text = []

    # Open and read the CSV file
    with open(file_path, 'r') as csvfile:
        csvreader = csv.reader(csvfile)
        next(csvreader)  # Skip the header

        for row in csvreader:
            if row[0]:  # Ensure row[0] (Seconds Index) is not empty
                time_in_seconds = float(row[0])
                text = row[1].strip()

                # Check if time falls within the specified interval
                if start_interval <= time_in_seconds <= end_interval and text:
                    ones_place = int(time_in_seconds) % 10
                    interval_text.append(f"{ones_place}: '{text}'")

    # Concatenate the results into a single string
    return ', '.join(interval_text)


