from openai import OpenAI
import os
import re
import csv


client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY",
                                       "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"))

class AudioTranscriber:
    def __init__(self, client, model="whisper-1"):
        self.client = client
        self.model = model

    def transcribe_audio(self, audio_path, response_format="srt"):
        """Transcribes the audio file using OpenAI's Whisper API."""
        with open(audio_path, "rb") as audio_file:
            transcription = self.client.audio.transcriptions.create(
                model=self.model,
                file=audio_file,
                response_format=response_format
            )
        return transcription

    @staticmethod
    def convert_to_seconds(time_str):
        """Converts time in hh:mm:ss,ms format to total seconds."""
        hours, minutes, seconds_millis = time_str.split(":")
        seconds, millis = seconds_millis.split(",")
        total_seconds = int(hours) * 3600 + int(minutes) * 60 + int(seconds) + int(millis) / 1000
        return total_seconds

    def format_srt_to_csv(self, srt_content, output_file):
        """Parses SRT content and writes it to a CSV file with two columns: seconds index and text."""
        pattern = r"(\d{2}:\d{2}:\d{2},\d{3}) --> (\d{2}:\d{2}:\d{2},\d{3})\n(.*)"
        written_phrases = set()

        # Open the output file as a CSV
        with open(output_file, 'w', newline='') as csvfile:
            csvwriter = csv.writer(csvfile)
            # Write the header
            csvwriter.writerow(["Seconds Index", "Text"])

            # Iterate over matches in the SRT content
            for match in re.finditer(pattern, srt_content):
                end_time = match.group(2)
                text = match.group(3).replace("\n", " ").strip()
                end_seconds = self.convert_to_seconds(end_time)

                # Write unique phrases only (if not repeated)
                if text not in written_phrases:
                    written_phrases.add(text)
                    # Write the seconds and the corresponding text to the CSV file
                    csvwriter.writerow([f"{end_seconds:.2f}", text])
                    csvfile.flush()  # Flush after each row to ensure immediate write

