from openai import OpenAI
import os
import base64
import sys
import cv2
from moviepy.editor import VideoFileClip
import base64
from WhisperExtractor import AudioTranscriber
from IntervalSpeech import extract_text_from_csv



class VideoProcessor:
    def __init__(self, client, video_path):
        self.client = client
        self.video_path = video_path
        self.base64Frames = []
        self.totalTokens = 0
        self.totalPromptTokens = 0
        self.totalCompletionTokens = 0
        self.csvPath = ""

    def process_video(self, seconds_per_frame=1):
        base_video_path, _ = os.path.splitext(self.video_path)

        video = cv2.VideoCapture(self.video_path)
        total_frames = int(video.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = video.get(cv2.CAP_PROP_FPS)
        frames_to_skip = int(fps * seconds_per_frame)
        curr_frame = 0

        while curr_frame < total_frames - 1:
            video.set(cv2.CAP_PROP_POS_FRAMES, curr_frame)
            success, frame = video.read()
            if not success:
                break
            _, buffer = cv2.imencode(".jpg", frame)
            self.base64Frames.append(base64.b64encode(buffer).decode("utf-8"))
            curr_frame += frames_to_skip
        video.release()

        audio_path = f"{base_video_path}.mp3"
        clip = VideoFileClip(self.video_path)
        clip.audio.write_audiofile(audio_path, bitrate="32k")
        clip.audio.close()
        clip.close()

        return len(self.base64Frames)

    def check_and_transcribe_audio(self):

        base_video_path, _ = os.path.splitext(self.video_path)
        frameCount = len(self.base64Frames)

        if os.path.exists(f"{base_video_path}.csv"):
            print("Decoded Audio File Found")
            self.csvPath = f"{base_video_path}.csv"
        else:
            print("Decoded Audio File Does Not Exist!")
            audioLength = float(cv2.VideoCapture(self.video_path).get(cv2.CAP_PROP_FRAME_COUNT)) / cv2.VideoCapture(self.video_path).get(cv2.CAP_PROP_FPS)
            decode_audio_answer = input(f"Would you like to spend approximately ${round((audioLength * .0001667), 5)} to decode it? (yes/no) ").strip().lower()
            if decode_audio_answer == "yes":
                transcriber = AudioTranscriber(self.client)
                audio_path = f"{base_video_path}.mp3"
                transcription = transcriber.transcribe_audio(audio_path)
                output_file = f"{base_video_path}.csv"
                transcriber.format_srt_to_csv(transcription, output_file)
                print(f"Decoded Audio Saved to {output_file}")
                self.csvPath = output_file



    def process_tokens_and_context_shifts(self, model):
        first = -10
        last = 0
        frameRange = int(len(self.base64Frames) / 10) + 1

        for x in range(frameRange):
            if last + 10 > len(self.base64Frames):
                last = last + (len(self.base64Frames) % 10)
            else:
                last = last + 10
            first = first + 10

            response = self.client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": "You will be given a sequence of images each apart of a larger video."
                                                  " There are two main events."
                                                  "Context shift and turn. A context shift is when there is a change in "
                                                  "architecture indicating there is a change in the environment. A"
                                                  "turn is when the person turns left or right and continues"
                                                  "to move in that direction."},
                    {"role": "user", "content": [
                        f"I would like a very specific annotation protocol revolving these images."
                        f"I need to know IF an event happens and if so between what two out"
                        f"of the ten images that that happens."
                        f"If an event does happen then I need to know on what images that happens."
                        f"The answer should always be in the format... '[Event] occurs between images x and y | [short description of event]' or "
                        f"'No event detected'",
                        *map(lambda x: {"type": "image_url", "image_url": {"url": f'data:image/jpg;base64,{x}', "detail": "low"}}, self.base64Frames[first:last]),
                        #{"type": "text", "text": f"Potential Audio: {extract_text_from_csv(self.csvPath, first, last) or 'No audio available.'}"},
                    ]},


                    # Added message
                ],
                temperature=0,
            )

            self.totalTokens += response.usage.total_tokens
            self.totalPromptTokens += response.usage.prompt_tokens
            self.totalCompletionTokens += response.usage.completion_tokens

            print(f"Seconds Index {first} - {last} : {response.choices[0].message.content}")

    def show_token_usage(self):
        print("\n")
        user_input_tokens = input("Would you like to see your token usage? (yes/no): ").strip().lower()

        if user_input_tokens == "yes":
            print(f"Total tokens used: {self.totalTokens}")
            print(f"Total Prompt tokens: {self.totalPromptTokens}")
            print(f"Total Completion tokens: {self.totalCompletionTokens}")
            promptCost = round((self.totalPromptTokens * .0000025), 5)
            print(f"Cost from Prompt Tokens: ${promptCost}")
            responseCost = round((self.totalCompletionTokens * .00001), 5)
            print(f"Cost from Response Tokens: ${responseCost}")
            print(f"Total Actual Cost: {round((promptCost + responseCost), 4)}")
        else:
            print("Exiting the program.")
            sys.exit()

    def calculate_cost(self):
        # 3 cents per 100 frames
        cost = len(self.base64Frames) * .0003
        frameCount = len(self.base64Frames)

        while True:
            user_input = input(f"Processing {frameCount} seconds at 1 FPS will cost approximately ${round(cost, 5)}. \n"
                               f"Would you like to proceed? (yes/no): ").strip().lower()
            if user_input == 'yes':
                print("Continuing...\n")
                break
            elif user_input == 'no':
                print("Exiting the program.")
                sys.exit()  # This will exit the entire program
            else:
                print("Invalid input. Please enter 'yes' or 'no'.")

# Main function
def main():


    client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY",
                                        "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"))


    # Get video path from user
    user_input_filePath = input("Please enter the filepath to the video you want to be annotated: ")
    VIDEO_PATH = user_input_filePath

    # Initialize VideoProcessor
    processor = VideoProcessor(client, VIDEO_PATH)

    # Process the video
    print("Extracting Frames...")
    frame_count = processor.process_video()

    # Check and transcribe audio if necessary
    processor.check_and_transcribe_audio()

    # Calculate cost
    processor.calculate_cost()

    # Process tokens and context shifts
    MODEL = "gpt-4o"  # Ensure this is set to your correct model
    processor.process_tokens_and_context_shifts(MODEL)

    # Show token usage
    processor.show_token_usage()

# Run the main function
if __name__ == "__main__":
    main()
