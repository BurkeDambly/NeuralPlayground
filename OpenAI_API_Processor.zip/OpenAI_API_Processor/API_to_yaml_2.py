import yaml
import re

def parse_text_to_yaml(input_file, output_file):
    with open(input_file, 'r', encoding='utf-8') as file:
        text = file.read()

    # Regular expression to match 'Seconds Index' blocks
    block_pattern = r"Seconds Index (\d+) - (\d+) :(.*?)(?=Seconds Index \d+ - \d+ :|$)"
    blocks = re.findall(block_pattern, text, re.DOTALL)

    yaml_data = {}

    for block in blocks:
        start_sec = int(block[0])
        end_sec = int(block[1])
        description = block[2].strip()

        # Initialize seconds with empty strings
        for second in range(start_sec, end_sec):
            yaml_data[second] = ""

        # Look for image number pairs
        image_nums = re.findall(r"images?\s*(\d+)\s*(?:and|&|-|to)\s*(\d+)", description)

        if image_nums:
            for image_pair in image_nums:
                image_num1 = int(image_pair[0])
                image_num2 = int(image_pair[1])

                # Map image_num2 to the corresponding second
                total_images = 10  # Assuming 10 images per block
                seconds_in_block = end_sec - start_sec
                seconds_per_image = seconds_in_block / total_images

                # Adjust image indices (assuming images are numbered from 1 to 10)
                image_index = image_num2 - 1  # Zero-based index
                event_second = start_sec + int(image_index * seconds_per_image)

                # Annotate the event second with the entire description
                yaml_data[event_second] = f"Event: {description}"

    # Sort the yaml_data by keys (seconds)
    sorted_yaml_data = dict(sorted(yaml_data.items()))

    # Write to YAML file
    with open(output_file, 'w', encoding='utf-8') as yaml_file:
        yaml.dump(sorted_yaml_data, yaml_file, default_flow_style=False, allow_unicode=True)

if __name__ == "__main__":
    input_file = "APIout.txt"  # Replace with your input text file
    output_file = "output2.yaml"
    parse_text_to_yaml(input_file, output_file)