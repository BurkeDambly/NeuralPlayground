import pandas as pd
import math
import yaml

def generate_yaml_from_csv(input_csv, output_yaml):
    # Read the CSV file
    df = pd.read_csv(input_csv)

    # Convert timestamps to seconds and round to the nearest second
    df['Rounded Timestamp'] = df['Timestamp'].apply(
        lambda x: round(sum(float(t) * 60 ** i for i, t in enumerate(reversed(x.split(':')))))
    )

    # Group events by rounded timestamps
    grouped = df.groupby('Rounded Timestamp').apply(
        lambda x: ", ".join(
            f"{row['Event']}: {row['Description']}" if pd.notna(row['Description']) else f"{row['Event']}:"
            for _, row in x.iterrows()
        )
    ).to_dict()

    # Create a full range of seconds from 0 to the maximum timestamp
    full_range = range(0, max(grouped.keys()) + 1)

    # Write the YAML file
    with open(output_yaml, "w") as file:
        for time in full_range:
            if time in grouped and grouped[time]:  # Write events if present
                file.write(f'{time}: "{grouped[time]}"\n')
            else:  # Write an empty string for blank lines
                file.write(f'{time}: ""\n')


# Example usage:
generate_yaml_from_csv("timestampeddataRW1Walk1 (2).csv", "ground_truth.yaml")