import pandas as pd

# Function to convert GoProFrame to timestamp in minutes:seconds format
def frame_to_timestamp(frame, fps=120):
    total_seconds = frame / fps
    minutes = int(total_seconds // 60)
    seconds = total_seconds % 60
    return f"{minutes}:{seconds:.2f}"

# Read the input CSV file (I think that reading in files on a Mac is different, if you are one mac and this doesn't work then try using single back slashes).
input_file = 'C:\\Users\\burke\\OneDrive\\Desktop\\CPS\\RW2\\RWNApp_RW2\\label\\evnts_RWNApp_RW2_Walk1.csv'
df = pd.read_csv(input_file)

# Select the first two columns and convert GoProFrame to timestamp
df['Timestamp'] = df['GoProFrame'].apply(frame_to_timestamp)
output_df = df[['Event', 'Description', 'Timestamp']]

# Write the output to a new CSV file
output_file = 'C:\\Users\\burke\\OneDrive\\Desktop\\Extract labels Pipeline\\TimeStampedDataWalk1.csv'
output_df.to_csv(output_file, index=False)

print(f"Processed file saved as {output_file}")